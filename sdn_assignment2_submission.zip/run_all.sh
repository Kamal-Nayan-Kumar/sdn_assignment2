#!/usr/bin/env bash
# Run every check in the submission, in order.
#   usage: bash run_all.sh [--no-e2e]
set -eu
cd "$(dirname "$0")"

PY=python3
[ -x .venv/bin/python ] && PY=.venv/bin/python

# The vendored POX and Mininet checkouts are third-party and are not shipped
# in this bundle.  Everything that needs them (the offline tests import POX to
# verify the OpenFlow wire format) will report a clear message here instead of
# an import traceback.
if [ ! -f pox/pox.py ]; then
  cat <<MSG
==========================================
 Missing third-party dependencies
==========================================
This bundle contains ONLY this assignment's code: the app, switch, topology,
LLM policy generator and tests.  To actually RUN the tests or the network you
also need the two checkouts this project builds on:

  git clone https://github.com/noxrepo/pox.git pox
  git clone https://github.com/mininet/mininet.git mininet
  make -C mininet

Then, from this directory:

  bash install_firewall_app.sh     # put app/firewall.py where POX wants it
  python3 -m pytest tests/ -q      # 51 tests
  unshare -Urn bash run_e2e.sh --batch

Nothing needs the network to READ the report: report/report.pdf has the
architecture, implementation, environment, limitations and results.
MSG
  exit 2
fi

echo "=========================================="
echo "1/4  Offline test suite"
echo "=========================================="
$PY -m pytest tests/ -q

echo
echo "=========================================="
echo "2/4  Policy file and the rules POX loads"
echo "=========================================="
cat firewall_rules.rules

if [ "${1:-}" != "--no-e2e" ]; then
  echo
  echo "=========================================="
  echo "3/4  End-to-end: POX + oswitch + Mininet"
  echo "=========================================="
  # Needs unshare for the user namespace; may need ./install_firewall_app.sh
  # first if pox/ is a fresh checkout.
  if unshare -Urn true 2>/dev/null; then
    unshare -Urn bash run_e2e.sh --batch
  else
    echo "  (skipped: unshare unavailable on this host)"
    bash run_e2e.sh --batch
  fi
fi

echo
echo "=========================================="
echo "4/4  Done. Report: report/report.pdf"
echo "=========================================="
