# SDN Assignment 2

**`report.pdf`** — the report: architecture, implementation details,
environment setup, known limitations, results, and all screenshots.
Read this first.

**`code/`** — everything needed to reproduce the results. See
`code/COMMAND.md` for the full command list and `code/README.md` for an
overview.

Quick start, from inside `code/`:

```bash
python3 -m pytest tests/ -q        # 51 offline tests, ~1s, no network
unshare -Urn bash run_e2e.sh --batch   # full end-to-end: 33% dropped
```

`run_all.sh` runs both in sequence and prints what it did.
